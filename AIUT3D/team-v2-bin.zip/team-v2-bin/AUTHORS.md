# Authors
---
Affiliation : Isfahan University of Technology

The following people have been members of the AIUT3D RoboCup team and have directly or indirectly contributed to this code:

- Navid Hossini Izadi
- Mohamad Roshanzamir
- Mehdi Tajmir Riahi
- Mehdi Abassi Soureshjani
- Seyed Yaghoob Ashkoofaraz
- Dr. Maziar Palhang (Team Leader)
