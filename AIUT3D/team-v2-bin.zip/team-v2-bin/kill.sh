#!/bin/bash
#
# AIUT3D kill script for 3D Simulation Competitions
#

# Kill agents
AGENT="aiut3d"
killall -9 $AGENT
sleep 1

